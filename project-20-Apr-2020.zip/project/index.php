<?php 
include 'web/index.php';
?>