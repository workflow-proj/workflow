function saveData(){
debugger;
   console.log('Current Id '+selectedId);
    var json_data='';
    var jsonArray = {};
    parent=[]
    var mainArr={}
    jsonArray["selectedId"]=selectedId;
    jsonArray["elementType"]=elementType;
    jsonArray["elementSubType"]=elementSubType;
    console.log('Start Data');
    json_data=$('#seModal').serialize().split('&');
    //jsonArray.push(parent);
    
    $.each(json_data, function (key, value) {
       var item = {};
       var splittedValue = value.split('=');               
       jsonArray[splittedValue[0]]=splittedValue[1]
   });
    console.log('Json Array '+jsonArray)
    console.log('Json Data '+json_data);
    console.log('Save Data Called');
// Managing Local Storage
    // Store Data
    localStorage.setItem(selectedId, JSON.stringify(jsonArray));
    semodal.style.display = "none";
    alert('Data saved successfully!');
    
}

function populateData(blockId){
   if(localStorage.getItem(blockId)){
       var localData=JSON.parse(localStorage.getItem(blockId));
       console.log('Getting Data From Local Storage');
       console.log(localData);
       // Populate Data
       console.log(localData);
       if(localData.id!=''){
           $("#keywordname").val(localData.keywordname);
           $("#keyword").val(localData.keyword);
           $("#command").val(localData.command);
           $("#functionname").val(localData.functionname);
           $("#responseoutput").val(localData.responseoutput);
           $("#inputtype").val(localData.inputtype);
           $("#inputformat").val(localData.inputformat);
           $("#stepno").val(localData.stepno);
           $("#stepno").val(localData.stepno);
           $("#nextprocess").val(localData.nextprocess);
           $("#functiontoperform").val(localData.functiontoperform);
           $("#functiontogetdata").val(localData.functiontogetdata);
           $("#responseformat").val(localData.responseformat);
       }
       console.log('End Localstorage fetch data');
    }else{
       $("#seModal").trigger("reset");
        console.log('No Data Found for Current Key');
    }
}

function saveWorkFlow(){
    debugger;
    console.log('BPNM JSON ');
    localstorageDate=allStorage();
    console.log('Local Storage Data');
    console.log(JSON.stringify(localstorageDate));
    console.log(JSON.stringify(bpmnjson));
    $('#workflow_json').val(JSON.stringify(bpmnjson));
    $('#workflow_data').val(JSON.stringify(localstorageDate));
    $('#FModal').show();
    console.log('End');
}
function allStorage() {

    var archive = {}, // Notice change here
    keys = Object.keys(localStorage),
    i = keys.length;

    while ( i-- ) {
        archive[ keys[i] ] = localStorage.getItem( keys[i] );
    }

    return archive;
}

function clone_form() {
    alert('Clone Clicked !')
    /*var row = $(clonebutton).parent(),
      inputVal = row.find('input').val(),
      selectVal = row.find('select').val(),
      original = $('#divRow0'),
      clone = $(original).clone(true, true);
    clone.find('#divRow0').prop('id', 'divRow' + $('.clonerow').length);
    clone.find('#innerDivRow0').prop('id', 'innerDivRow' + $('.clonerow').length);
    clone.find('input[type="text"]').val(inputVal);
    clone.find('select').val(selectVal);
    $('#container').append(clone);*/
    $("#SEModal").clone().appendTo(".modal-body"); 
  }
  function drawGraph(grapOBJ){
      console.log('From Workflow.js');
      console.log(grapOBJ);
      alert('drawGraph Method Called Anuj');
      console.log('From JSON Obj Method workflow.js');
  }