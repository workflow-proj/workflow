var elementArray={};
function saveData(){
debugger;
   console.log('Current Id '+selectedId);
    var json_data='';
    
    var formArray={};
    parent=[]
    var mainArr={}
    
    console.log('Start Data');
    //json_data=$('#seModal').serialize().split('&');
    total_forms=parseInt($("#form_size").val());
    for(var count=0;count<=total_forms;count++){
        var jsonArray = {};
        jsonArray["selectedId"]=selectedId;
        jsonArray["elementType"]=elementType;
        jsonArray["elementSubType"]=elementSubType;
        var form_id='seModal'+count;
        console.log(form_id);
        json_data=$('#'+form_id).serialize().split('&');
        //jsonArray.push(parent);
        
        $.each(json_data, function (key, value) {
            var item = {};
            var splittedValue = value.split('=');               
            jsonArray[splittedValue[0]]=splittedValue[1];
        });
        formArray[count]=jsonArray;
    }
    elementArray[selectedId]=formArray;
    console.log('Element Array');
    console.log(elementArray);
    console.log(JSON.stringify(jsonArray));
    console.log('End');
    console.log('Json Array '+jsonArray)
    console.log('Json Data '+json_data);
    console.log('Save Data Called');
// Managing Local Storage
    // Store Data
    //localStorage.setItem(selectedId, JSON.stringify(jsonArray));
    localStorage.setItem('formData', JSON.stringify(elementArray));
    semodal.style.display = "none";
    alert('Data saved successfully!');
    
}
//// Function for saving Mongo Data
function saveMongoData(){
	debugger;
	var baseURL='/project/web';
	alert('Save Mongo data called');
	alert('Base URL '+baseURL);
	$.ajax({
        dataType: "json",
        url: baseURL + '/mongo-workflow/create',
        type: 'POST',
        cache: false,
        data: {'id':1},
        success: function (response) {
                console.log('Success'+response);
        },
        error: function(xhr, status, error) {
        	  var err = eval("(" + xhr.responseText + ")");
        	  alert(err.Message);
        }

    });
	$.ajax({
	    type: "POST",
	    url: baseURL + '/mongo-workflow/create',,
	    data: DATA,
	    dataType: "json",
	    success: function (json) {
	        //Do something with the returned json object.
	    },
	    error: function (xhr, status, errorThrown) {
	        //Here the status code can be retrieved like;
	        xhr.status;

	        //The message added to Response object in Controller can be retrieved as following.
	        xhr.responseText;
	    }
	});
}
function populateData(blockId){
    /* ----------------------- Testing ------------------------*/
    debugger;
    if(localStorage.getItem('formData')){
        var localJSONData=JSON.parse(localStorage.getItem('formData'));
        var localData=localJSONData[blockId];
        if(localData){
            console.log('Getting Data From Local Storage');
            console.log(localData);
            // Populate Data
            len=Object.keys(localData).length;
            current_forms=$("#form_size").val();
            if(len>1){
                for(var nf=current_forms;nf<len-1;nf++){
                    clone_form();
                }
            }
            $("#form_size").val(len-1);
            console.log(localData);
            for(var el=0;el<len;el++){
                if(localData[el]){
                    if(localData.id!=''){
                        $("#keywordname"+el+"").val(localData[el]['keywordname'+el]);
                        $("#keyword"+el+"").val(localData[el]['keyword'+el]);
                        $("#command"+el+"").val(localData[el]['command'+el]);
                        $("#functionname"+el+"").val(localData[el]['functionname'+el]);
                        $("#responseoutput"+el+"").val(localData[el]['responseoutput'+el]);
                        $("#inputtype"+el+"").val(localData[el]['inputtype'+el]);
                        $("#inputformat"+el+"").val(localData[el]['inputformat'+el]);
                        $("#stepno"+el+"").val(localData[el]['stepno'+el]);
                        $("#stepno"+el+"").val(localData[el]['stepno'+el]);
                        $("#nextprocess"+el+"").val(localData[el]['nextprocess'+el]);
                        $("#functiontoperform"+el+"").val(localData[el]['functiontoperform'+el]);
                        $("#functiontogetdata"+el+"").val(localData[el]['functiontogetdata'+el]);
                        $("#responseformat"+el+"").val(localData[el]['responseformat'+el]);
                    }
                    console.log('End Localstorage fetch data');
                }else{
                    $("#seModal0").trigger("reset");
                    console.log('No Data Found for Current Key');
                }
            }
        }else{
            // For Removing Extra Forms
            current_forms=$("#form_size").val();
            if(current_forms>0){
                for(i=1;i<=current_forms;i++){
                    $("#accordion").remove("#seModal"+i+"");
                }
            }
            $("#form_size").val('0');
            $("#seModal0").trigger("reset");
        }
    }
    /* ------------------------- End   ------------------------*/
   /*if(localStorage.getItem(blockId)){
       var localData=JSON.parse(localStorage.getItem(blockId));
       console.log('Getting Data From Local Storage');
       console.log(localData);
       // Populate Data
       console.log(localData);
       if(localData.id!=''){
           $("#keywordname").val(localData.keywordname);
           $("#keyword").val(localData.keyword);
           $("#command").val(localData.command);
           $("#functionname").val(localData.functionname);
           $("#responseoutput").val(localData.responseoutput);
           $("#inputtype").val(localData.inputtype);
           $("#inputformat").val(localData.inputformat);
           $("#stepno").val(localData.stepno);
           $("#stepno").val(localData.stepno);
           $("#nextprocess").val(localData.nextprocess);
           $("#functiontoperform").val(localData.functiontoperform);
           $("#functiontogetdata").val(localData.functiontogetdata);
           $("#responseformat").val(localData.responseformat);
       }
       console.log('End Localstorage fetch data');
    }else{
       $("#seModal").trigger("reset");
        console.log('No Data Found for Current Key');
    }*/
}

function saveWorkFlow(){
    var final_json={};
    final_json['bpmn']=bpmnjson;
    debugger;
    console.log('BPNM JSON ');
    localstorageData=localStorage.getItem('formData');
    console.log('Local Storage Data');
    console.log(JSON.stringify(localstorageData));
    console.log(JSON.stringify(bpmnjson));
    //$('#workflow_json').val(JSON.stringify(bpmnjson));
    $('#workflow_json').val(JSON.stringify(final_json));
    $('#workflow_data').val(localstorageData);
    // For Clearing Local Storage
    //localStorage.clear();
    $('#FModal').show();
    console.log('End');
}
function clearLocalStorage(){
    localStorage.clear();
}
function allStorage() {

    var archive = {}, // Notice change here
    keys = Object.keys(localStorage),
    i = keys.length;

    while ( i-- ) {
        archive[ keys[i] ] = localStorage.getItem( keys[i] );
    }

    return archive;
}

function clone_form() {
    var i=parseInt($("#form_size").val())+1;
    new_element='<div class="panel panel-default">';
    new_element+='<form id="seModal'+i+'" action="" name="seModal'+i+'">';
    new_element+='<div class="panel-heading" role="tab" id="heading'+i+'">';
    new_element+='<h4 class="panel-title"><a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse'+i+'" aria-expanded="true" aria-controls="collapse'+i+'">Event Configuration</a></h4></div>';
    new_element+='<div id="collapse'+i+'" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading'+i+'"><div class="panel-body"><div class="form-group"><label>Name Of the keyword</label><input type="text" class="form-control" id="keywordname'+i+'" name="keywordname'+i+'" placeholder="Name of the Keyword"></input></div>';
    new_element+=' <div class="form-group"><label>Step No</label><input type="text" class="form-control" id="stepno'+i+'" name="stepno'+i+'" placeholder="Step No"></input></div>';
    new_element+='<div class="form-group"><label>Next Process</label><input type="text" class="form-control" id="nextprocess'+i+'" name="nextprocess'+i+'" placeholder="Next Process"></input></div>';
    new_element+='<div class="form-group"><label>Function to perform in form</label><input type="text" class="form-control" id="functiontoperform'+i+'" name="functiontoperform'+i+'" placeholder="Function to perform in form"></input></div>';
    new_element+='<div class="form-group"><label>Function to get the data</label><input type="text" class="form-control" id="functiontogetdata'+i+'" name="functiontogetdata'+i+'" placeholder="Function to get data"></input></div>';
    new_element+=' <div class="form-group"><label>Response Format</label> <input type="text" class="form-control" id="responseformat'+i+'" name="responseformat'+i+'" placeholder="Response format"></input></div>';
    new_element+='<div class="form-group"><label>Keyword</label><select id="keyword'+i+'" name="keyword'+i+'" class="form-control"><option value="">Please Select Keyword</option><option value="keyword-1">Keyword-1</option><option value="keyword-2">Keyword-2</option><option value="keyword-3">Keyword-3</option><option value="keyword-4">Keyword-4</option></select></div>';
    new_element+='<div class="form-group"><label>Select Command</label><select id="command'+i+'" name="command'+i+'" class="form-control"><option value="">Please Select Keyword</option><option value="command-1">command-1</option><option value="command-2">command-2</option><option value="command-3">command-3</option><option value="command-4">command-4</option></select></div>';
    new_element+='<div class="form-group"><label>Function to perform</label><select id="functionname'+i+'" name="functionname'+i+'" class="form-control"><option value="">Please Select Function</option><option value="functionname-1">functionname-1</option><option value="functionname-2">functionname-2</option><option value="functionname-3">functionname-3</option><option value="functionname-4">functionname-4</option></select></div>';
    new_element+='<div class="form-group"><label>Response Output</label><input type="text" class="form-control" id="responseoutput'+i+'" name="responseoutput'+i+'" placeholder="Response Output"></input></div>';
    new_element+='<div class="form-group"><label>Input Type</label><select id="inputtype'+i+'" name="inputtype'+i+'" class="form-control"><option value="">Please Select Input Type</option><option value="inputtype-1">inputtype-1</option><option value="inputtype-2">inputtype-2</option><option value="inputtype-3">inputtype-3</option><option value="inputtype-4">inputtype-4</option></select></div>';
    new_element+='<div class="form-group"><label>Input format data</label><input type="text" class="form-control" id="inputformat'+i+'" name="inputformat'+i+'" placeholder="Input Format"></input></div>';
    new_element+='</div></div>';
    new_element+='</form></div>';

    /*var row = $(clonebutton).parent(),
      inputVal = row.find('input').val(),
      selectVal = row.find('select').val(),
      original = $('#divRow0'),
      clone = $(original).clone(true, true);
    clone.find('#divRow0').prop('id', 'divRow' + $('.clonerow').length);
    clone.find('#innerDivRow0').prop('id', 'innerDivRow' + $('.clonerow').length);
    clone.find('input[type="text"]').val(inputVal);
    clone.find('select').val(selectVal);
    $('#container').append(clone);*/
    //$("#formgroup").clone().appendTo("#accordion"); 
    $("#accordion").append(new_element);
    $("#form_size").val(i);
  }
  function drawGraph(grapOBJ,formObj){
      console.log(formObj);
      uploadgraphCreator(grapOBJ);
      localStorage.setItem('formData', JSON.stringify(formObj));
  }