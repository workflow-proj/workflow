<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Workflow */
//echo '<pre>';
print_r($model['workflow_json']);
echo '<br>';
print_r($model['workflow_data']);
//die;
$this->title = 'Update Workflow: ' . $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Workflows', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<script>
</script>
<!DOCTYPE HTML>
<html>
  <head>
  
  </head>

  <body >

 <div id="mySvg"></div>
    <div id="toolbox_other">
      <input type="file" id="hidden-file-upload"><input id="upload-input" type="image" title="upload graph" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/upload-icon.png' ?>"> <input type="image" id="download-input" title="download graph" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/download-icon.png' ?>" alt="download graph">
       <!-- <input type="image" id="delete-graph" title="delete graph" src="/project/web/assets/BPNM/img/trash-icon.png" alt="delete graph">  -->
    </div>
    <textarea id="edittext" title="Press SHIFT+Enter for line feed" style="width: 120px; height: 80px; left: 608px; top: 180px; position: absolute; text-align: center; box-sizing: border-box; margin: 0px; display: none;"></textarea>

    <div id="toolbox">
     <!--  <input type="file" id="hidden-file-upload"> -->
    <!--  <span><b>Start Event</b></span><br> -->
     <input id="start-button" type="image" title="Start Event" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/startevent.png' ?>" alt="Start Event" style="width: 30px;height: 30px">
     <input id="start-time-button" type="image" title="Time Event" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/timestartevent.png' ?>" alt="Time Event" style="width: 30px;height: 30px"><br>
     <input id="start-message-button" type="image" title="Message Start Event" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/messagestartevent.png' ?>" alt="Message Start Event" style="width: 30px;height: 30px">
     <input id="start-error-button" type="image" title="Error Start Event" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/errorstartevent.png' ?>" alt="Error Start Event" style="width: 30px;height: 30px"><br>
     <hr>
    <!--  <span><b>End Event</b></span><br> -->
     <input id="end-button" type="image" title="End Event" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/black-circle.png' ?>" alt="End Event" style="width: 30px;height: 30px">
      <input id="error-end-button" type="image" title="Error End Event" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/errorend.png' ?>" alt="Error End Event" style="width: 30px;height: 30px"><br>
      <input id="terminate-end-button" type="image" title="Terminate End Event" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/terminateend.png' ?>" alt="Terminate End Event" style="width: 30px;height: 30px">
      <input id="cancel-end-button" type="image" title="Cancel End Event" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/cancelend.png' ?>" alt="Cancel End Event" style="width: 30px;height: 30px"><br>
      <hr>
     <!--  <span><b>Task</b></span><br> -->
      <input id="user-task-button" type="image" title="User Task" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/user.svg' ?>" alt="User Task" style="width: 30px;height: 30px">
      <input id="script-task-button" type="image" title="Script Task" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/script.svg' ?>" alt="Script Task" style="width: 30px;height: 30px"><br>
      <input id="mail-task-button" type="image" title="Mail Task" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/message.svg' ?>" alt="Mail Task" style="width: 30px;height: 30px">
      <input id="manual-task-button" type="image" title="Manual Task" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/manual.svg' ?>" alt="Manual Task" style="width: 30px;height: 30px"><br>
      <hr>
    
     <input id="parallel-gateway-button" type="image" title="Parallel Gateway" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/parallelgateway.png' ?>" alt="Parallel Gateway" style="width: 30px;height: 30px">
      <input id="exclusive-gateway-button" type="image" title="Exclusive Gateway" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/Exclusivegateway.png' ?>" alt="Exclusive Gateway" style="width: 30px;height: 30px"><br>
      <input id="inclusive-gateway-button" type="image" title="Inclusive Gateway" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/inclusivedateway.png' ?>" alt="Inclusive Gateway" style="width: 30px;height: 30px">
      <input id="event-gateway-button" type="image" title="Event Gateway" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/Eventgateway.png' ?>" alt="Event Gateway" style="width: 30px;height: 30px"><br>
      <hr>
  <!--     <span><b>Connections</b></span><br> -->
      <input id="arrow-button" type="image" title="Sequence Flow" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/arrow.png' ?>" alt="Sequence Flow" style="width: 30px;height: 30px"><br>
    <hr>
    <img type="image" src="<?php echo Yii::$app->request->baseUrl.'/assets/BPNM/img/settingsicon.png' ?>" style="width: 30px;height: 30px" onClick="saveWorkFlow()">
    </div>
    <!----------------------------------------- Testing Area ----------------------------------->
    <!-------------------------------------------- End -----------------------------------------> 

    <!-- The Modal -->
    <div id="SEModal" class="modal"> 
      <!-- Modal content -->
      <div class="modal-content" style="width:1000px">
        <div class="modal-header">
          <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span id="SEClose" aria-hidden="true">&times;</span></button> -->
          <center><h4>Configure Workflow</h4></center>
        </div>
        <div class="modal-body">
        <form id="seModal" action="" name="seModal">
          <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
            <div class="panel panel-default">
              <div class="panel-heading" role="tab" id="headingOne">
                <h4 class="panel-title">
                  <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    Event Configuration
                  </a>
                </h4>
              </div>
              <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                <div class="panel-body">
                  <div class="form-group">
                    <label>Name Of the keyword</label>
                    <input type="text" class="form-control" id="keywordname" name="keywordname" placeholder="Name of the Keyword"></input>
                  </div>
                  <div class="form-group">
                    <label>Step No</label>
                    <input type="text" class="form-control" id="stepno" name="stepno" placeholder="Step No"></input>
                  </div>
                  <div class="form-group">
                    <label>Next Process</label>
                    <input type="text" class="form-control" id="nextprocess" name="nextprocess" placeholder="Next Process"></input>
                  </div>
                  <div class="form-group">
                    <label>Function to perform in form</label>
                    <input type="text" class="form-control" id="functiontoperform" name="functiontoperform" placeholder="Function to perform in form"></input>
                  </div>
                  <div class="form-group">
                    <label>Function to get the data</label>
                    <input type="text" class="form-control" id="functiontogetdata" name="functiontogetdata" placeholder="Function to get data"></input>
                  </div>
                  <div class="form-group">
                    <label>Response Format</label>
                    <input type="text" class="form-control" id="responseformat" name="responseformat" placeholder="Response format"></input>
                  </div>
                  <div class="form-group">
                    <label>Keyword</label>
                    <select id="keyword" name="keyword" class="form-control">
                      <option value="">Please Select Keyword</option>
                      <option value="keyword-1">Keyword-1</option>
                      <option value="keyword-2">Keyword-2</option>
                      <option value="keyword-3">Keyword-3</option>
                      <option value="keyword-4">Keyword-4</option>
                    </select>
                    <!--<input type="text" class="form-control" id="keyword" name="keyword" placeholder="Keyword"></input>-->
                  </div>
                  <div class="form-group">
                    <label>Select Command</label>
                    <select id="command" name="command" class="form-control">
                      <option value="">Please Select Keyword</option>
                      <option value="command-1">command-1</option>
                      <option value="command-2">command-2</option>
                      <option value="command-3">command-3</option>
                      <option value="command-4">command-4</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Function to perform</label>
                    <select id="functionname" name="functionname" class="form-control">
                      <option value="">Please Select Function</option>
                      <option value="functionname-1">functionname-1</option>
                      <option value="functionname-2">functionname-2</option>
                      <option value="functionname-3">functionname-3</option>
                      <option value="functionname-4">functionname-4</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Response Output</label>
                    <input type="text" class="form-control" id="responseoutput" name="responseoutput" placeholder="Response Output"></input>
                  </div>
                  <div class="form-group">
                    <label>Input Type</label>
                    <select id="inputtype" name="inputtype" class="form-control">
                      <option value="">Please Select Input Type</option>
                      <option value="inputtype-1">inputtype-1</option>
                      <option value="inputtype-2">inputtype-2</option>
                      <option value="inputtype-3">inputtype-3</option>
                      <option value="inputtype-4">inputtype-4</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Input format data</label>
                    <input type="text" class="form-control" id="inputformat" name="inputformat" placeholder="Input Format"></input>
                  </div>
                </div>
              </div>
            </div>
      </form>
       <!----- Testing Data -------------->
       
       <!----------- End ----------------->
      </div>
      <div class="modal-footer">
        <button id="SEClose" type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-default" onClick="clone_form()">Add New Step</button>
        <button type="button" class="btn btn-default" onClick="saveData()">Save</button>
        
      </div>
    </div>
  </div>
</div>
<!-------- ENd  First Modal --------------------->
<!------------- Modal for Saving The Data --------->
<div id="FModal" class="modal"> 
      <!-- Modal content -->
      <div class="modal-content">
      <form id="w0" action="/project/web/workflow/create" method="post">
        <div class="modal-header">
          <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span id="GClose" aria-hidden="true">&times;</span></button> -->
          
          <center><h4>Save Workflow</h4></center>
        </div>
        <input type="hidden" name="_csrf" value="LIZdfhe_4zU73ImVV9k2Zxcd82RMq-QXOS34nRNGhuRG1wsVSPXOZna--KwRq0EAJiTLDirFhWEIY72rWCrTow==">
        <input type="hidden" name="workflow_json" id="workflow_json" value="">
        <input type="hidden" name="workflow_data" id="workflow_data" value="">
        <div class="modal-body">
          <div class="form-group">
            <label>Workflow Title</label>
            <input type="text" id="workflow-workflow_title" class="form-control" name="Workflow[workflow_title]" maxlength="100">
          </div>
          <div class="form-group">
            <label>Workflow Description</label>
            <input type="text" id="workflow-workflow_description" class="form-control" name="Workflow[workflow_description]" maxlength="200">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" id="FClose">Cancel</button>
          <button type="submit" class="btn btn-default" onClick="saveWorkFlow()">Save</button>
        </div>
      </div>
      </form>
    </div> 
<!------------------------ End -------------------->
  </body>
</html>
<script>
document.addEventListener('DOMContentLoaded', function() {
   // your code here
   alert('Page Loaded');
   drawGraph(<?php echo $model['workflow_json']?>);
}, false);
</script>